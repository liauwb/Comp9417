#Gunners1996
import pandas as pd
import numpy as np
import math
from scipy.io import arff
import sys
import random
import matplotlib.pyplot as plt
from sklearn import datasets


np.set_printoptions(threshold=sys.maxsize)
def normalize_list_numpy(list):
    normalized_list = list / np.linalg.norm(list)
    return normalized_list
	
def linear_regression(data, labels, weights, num_epochs, learning_rate):
	for i in range(num_epochs):
		predictions = weights @ data
		gradientweight = ((predictions-labels)*data).mean(axis = 1)
		weights -= gradientweight*learning_rate
		#print(weights)
		cost = ((labels - predictions)**2).mean()
	print ("iter: "+str(i) + " cost: "+str(cost))	
	return weights
	
def perceptron(data, labels, weights, num_epochs, learning_rate):
	bestcost = len(data[0])
	tempweights = weights
	for i in range(num_epochs):
		temp = random.randint(0,len(data[0])-1)
		prediction = (tempweights @ data[:,temp])
		if prediction >= 0:
			prediction = 1
		else:
			prediction = 0
		
		gradientweight = ((labels[temp]-prediction))
		tempweights = tempweights + gradientweight*data[:,temp]*learning_rate
		
		temppredictions = (tempweights @ data)
		#print(temppredictions)
		predictions = []
		for j in range(len(temppredictions)):
			if temppredictions[j] >= 0:
				predictions.append(1)
			else:
				predictions.append(0)
		
		cost = abs(predictions-labels)
		cost = cost.sum()
		
		if(bestcost > cost):
			weights = tempweights
		if cost == 0:
			break
	print ("iter: "+str(i) + " cost: "+str(cost))
	return weights

def pocketalg(data,labels,weights,num_epochs,learning_rate):
	rpercept = rpocket = 0
	ppocket = ppercept = len(data[0])
	weightpocket = weights
	for i in range(num_epochs):
		temp = random.randint(0,len(data[0])-1)
		prediction = (weights @ data[:,temp])
		if prediction >= 0:
			prediction = 1
		else:
			prediction = 0
		if prediction == labels[temp]:
			rpercept+=1
			if rpercept > rpocket:
				temppredictions = (weights @ data)
				#print(temppredictions)
				predictions = []
				for j in range(len(temppredictions)):
					if temppredictions[j] >= 0:
						predictions.append(1)
					else:
						predictions.append(0)
				cost = abs(predictions-labels)
				ppercept = cost.sum()
		#		print("Ppercept = " + str(ppercept))
				if ppercept < ppocket:
					weightpocket = weights
					rpocket = rpercept
					ppocket = ppercept
					if ppocket == 0:
						cost = cost.sum()
						print ("Pocket iter: "+str(i) + " cost: "+str(cost))
						return weightpocket
		else:
			gradientweight = ((labels[temp]-prediction))
			weights = weights + gradientweight*data[:,temp]*learning_rate
			rpercept = 0
		#print("weights = "+str(weights))
		#print("pocket weights = " + str(weightpocket))
		#print("Rpercept = " + str(rpercept))
		#print("Rpocket - " + str(rpocket))
		#print("Ppocket = " + str(ppocket))
		temppredictions = (weightpocket @ data)
		#print(temppredictions)
		predictions = []
		for j in range(len(temppredictions)):
			if temppredictions[j] >= 0:
				predictions.append(1)
			else:
				predictions.append(0)
		
		cost = abs(predictions-labels)
		cost = cost.sum()
	print ("Pocket iter: "+str(i) + " cost: "+str(cost))
	return weightpocket

f = open("autoMpg.arff")
data, meta = arff.loadarff(f)
x = data.tolist()


data = (np.array(x))
data = (np.nan_to_num(data.astype(float)))
labels = data[:,-1]
data = ((data[:,:-1]))
temp = np.ones((len(data),1))
data = np.append(data,temp,axis = 1)
weights = np.zeros(len(data[0])) 
num_epochs = 100000
learning_rate = 0.0000001
(linear_regression(data.T,labels,weights,num_epochs,learning_rate))

temp = np.genfromtxt("processed.cleveland.data",dtype = None)
data = []
for i in range(len(temp)):
	temp2 = ((temp[i].decode('UTF-8')))
	if '?' in temp2:
		continue
	data.append(temp2.split(','))
data = np.array([np.array(x) for x in data])

data = (data.astype(float))
labels = data[:,-1]

for i in range(len(labels)):
	if labels[i] > 0:
		labels[i] = 1
#print(labels)
data = ((data[:,:8]))
temp = np.ones((len(data),1))
data = np.append(data,temp,axis = 1)
weights = np.zeros(len(data[0])) 
num_epochs = 10000
learning_rate = 3
data = normalize_list_numpy(data)
#print(data)
(perceptron(data.T,labels,weights,num_epochs,learning_rate))
(pocketalg(data.T,labels,weights,num_epochs,learning_rate))


data, labels = datasets.make_blobs(n_samples=100, centers=2, n_features=8, center_box=(0, 10))
#print(data)
#print(labels)
temp = np.ones((len(data),1))
data = np.append(data,temp,axis = 1)
weights = np.zeros(len(data[0])) 
num_epochs = 100
learning_rate = 1
#print(data)
weights = (pocketalg(data.T,labels,weights,num_epochs,learning_rate))
(perceptron(data.T,labels,weights,num_epochs,learning_rate))